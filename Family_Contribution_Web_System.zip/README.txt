FAMILY CONTRIBUTION WEB APP
============================
Open index.html in a browser.

Demo admin password: Family500

IMPORTANT:
This version is a standalone demo. Changes are saved in the browser that makes them.
To make one shared live system for the whole WhatsApp group, upload/deploy index.html
to a web host and connect it to a shared database/authentication service.
